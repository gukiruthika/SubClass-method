package sample;

public class Assignment {

	public static void main(String[] args) {
		Parent parentObj = new Parent();
		Child childObj = new Child();
		parentObj.print(childObj);
	}

}
