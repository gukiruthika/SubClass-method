package sample;

public class Parent {
	
	void print(Child a) {
		a.println();
	}
	
}
