package sample;

public class Child extends Parent {
	void println() {
		System.out.println("println");
	}
}
