package sample;

abstract public class Parent {
	void print() {
		println();
	}

	abstract void println();
}
