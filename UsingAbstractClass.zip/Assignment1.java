package sample;

public class Assignment1 {

	public static void main(String[] args) {
		Parent obj = new Child();
		obj.print();
	}

}
